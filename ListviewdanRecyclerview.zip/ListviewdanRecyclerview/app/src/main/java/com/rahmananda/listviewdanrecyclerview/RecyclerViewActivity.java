package com.rahmananda.listviewdanrecyclerview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

public class RecyclerViewActivity extends AppCompatActivity {

    private RecyclerView rvBuah;
    private String[] namaBuah = {"Alpukat","Apel","Ceri","Durian","Jambu Air","Manggis","Strawberry"};
    private int[] gambarBuah = {
            R.drawable.alpukat,
            R.drawable.apel,
            R.drawable.ceri,
            R.drawable.durian,
            R.drawable.jambuair,
            R.drawable.manggis,
            R.drawable.strawberry
    };

    private int[] suaraBuah = {
                R.raw.alpukat,
                R.raw.apel,
                R.raw.ceri,
                R.raw.durian,
                R.raw.jambu_air,
                R.raw.manggis,
                R.raw.strawberry
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycler_view);

        rvBuah = findViewById(R.id.rv_buah);

        BuahAdapter adapterbuah = new BuahAdapter(namaBuah, gambarBuah,suaraBuah);

        rvBuah.setLayoutManager(new LinearLayoutManager(this));
        rvBuah.setHasFixedSize(true);
        rvBuah.setAdapter(adapterbuah);
    }
}

package com.rahmananda.listviewdanrecyclerview;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class ListView2Activity extends AppCompatActivity {
    private ListView lvKota;
    private String[] dataKota = {"Medan","Padang","Jambi","Lampung","Palembang","Palu","jakarta",
            "Bandung","Surabaya","Semarang"};
    private String[] deskripsi = {"Ibukota Sumatera Utara","Ibukota Sumatera Barat","Ibukota Jambi","Ibukota Lampung",
    "Ibukota Suamtera Seletan","Ibukota Sulawesi Tengah","ibukota Jakarta","Ibukota Jawa Barat","Ibukota Jawa Timur","Ibukota Jawa Tengah"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_view2);

        lvKota = findViewById(R.id.lv_ibukota);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_2, android.R.id.text1,dataKota){
            @NonNull
            @Override
            public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                View tampil =  super.getView(position, convertView, parent);

                TextView tv2 = tampil.findViewById(android.R.id.text2);
                tv2.setText(deskripsi[position]);
                return tampil;
            }
        };
        lvKota.setAdapter(adapter);
        lvKota.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(ListView2Activity.this, dataKota[position], Toast.LENGTH_SHORT).show();
            }
        });
    }
}
